package Worxogo;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RTN {
	public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
    
            driver.get("https://app.webpushr.com/login");
            		
            driver.manage().window().maximize();

            WebElement mail = driver.findElement(By.xpath("(//input[@class='text-field form-control'])[1]"));
            mail.sendKeys("kavitha.nw@worxogo.com");
            
            WebElement password = driver.findElement(By.xpath("(//input[@class='text-field form-control'])[2]"));
            password.sendKeys("NW@12345");
            
            WebElement signin = driver.findElement(By.xpath("//button[@class='btn btn-primary btn-block mt-3']"));
            signin.click();
            
          

}
}