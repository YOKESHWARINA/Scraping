import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Eatsure2 {

    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        Actions actions = new Actions(driver);

        try {
            driver.get("https://www.eatsure.com/");
            actions.sendKeys(Keys.ESCAPE).perform(); // Dismiss popup

            // Enter pincode
            WebElement locationSearch = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='text']")));
            locationSearch.click();
            locationSearch.sendKeys("560038");
            Thread.sleep(2000);

            WebElement locationClick = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='iconWrap']")));
            locationClick.click();
            System.out.println("Pincode entered and submitted successfully!");

            // Click Explore Restaurants
            WebElement exploreRestaurants = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[@class='Button-sc-3qnwiq-0 kVKCgs']")));
            exploreRestaurants.click();

            // Scroll and select brand
            String expectedText = "The Good Bowl";
            Thread.sleep(3000);

            List<WebElement> brandElements = driver.findElements(
                    By.xpath("//div[@class='style__BrandName-sc-1y2oa9k-5 leOroS']//p"));

            boolean found = false;
            for (WebElement element : brandElements) {
                String actualText = element.getText().trim();
                if (actualText.equalsIgnoreCase(expectedText.trim())) {
                    ((JavascriptExecutor) driver).executeScript(
                            "arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", element);
                    Thread.sleep(1000);
                    element.click();
                    found = true;
                    break;
                }
            }

            if (!found) {
                System.out.println("Brand not found: " + expectedText);
                return;
            }

            // Restaurant name
            WebElement restaurantName = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//div[@class='style__BrandName-p7ijs4-11 kNxxtn']")));
            ((JavascriptExecutor) driver).executeScript(
                    "arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", restaurantName);
            Thread.sleep(1000);
            System.out.println("Restaurant Name: " + restaurantName.getText());

            // Scroll down to load all items
            long lastHeight = (long) ((JavascriptExecutor) driver).executeScript("return document.body.scrollHeight");
            while (true) {
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight);");
                Thread.sleep(2000); // wait for content to load
                long newHeight = (long) ((JavascriptExecutor) driver).executeScript("return document.body.scrollHeight");
                if (newHeight == lastHeight) break;
                lastHeight = newHeight;
            }

            // Item list
            List<WebElement> itemNames = driver.findElements(By.xpath("//div[@data-qa='productName']"));
            System.out.println("Total items found: " + itemNames.size());

            // Debug: Count total price-label elements
            List<WebElement> priceLabels = driver.findElements(By.xpath("//span[@class='price-label']"));
            System.out.println("Total price-label elements found: " + priceLabels.size());

            for (int i = 0; i < itemNames.size(); i++) {
                WebElement item = itemNames.get(i);
                ((JavascriptExecutor) driver).executeScript(
                        "arguments[0].scrollIntoView({behavior: 'auto', block: 'center'});", item);
                wait.until(ExpectedConditions.visibilityOf(item));
                Thread.sleep(1000); // wait for lazy loading

                String itemText = item.getText().trim();

                // ---------- Price Handling ----------
                String priceText = "N/A";
                try {
                    WebElement primaryPrice = wait.until(ExpectedConditions.visibilityOfElementLocated(
                            By.xpath("(//h6[@class='style__OfferPrice-jfito-3 llYpsM priceTypeSlashed_PLP_PriceBar']//div[1])[" + (i + 1) + "]")
                    ));
                    priceText = primaryPrice.getText().trim();
                } catch (Exception e1) {
                    int fallbackIndex = i + 1;
                    try {
                        System.out.println("Checking fallback price for index " + fallbackIndex + " with XPath: (//span[@class='price-label'])[" + fallbackIndex + "]");
                        List<WebElement> allPriceLabels = driver.findElements(By.xpath("//span[@class='price-label']"));
                        if (fallbackIndex <= allPriceLabels.size()) {
                            WebElement fallbackPrice = wait.until(ExpectedConditions.visibilityOfElementLocated(
                                    By.xpath("(//span[@class='price-label'])[" + fallbackIndex + "]")
                            ));
                            priceText = fallbackPrice.getText().trim();
                        } else {
                            System.out.println("Fallback index " + fallbackIndex + " exceeds total price-label elements (" + allPriceLabels.size() + ")");
                        }
                    } catch (Exception e2) {
                        System.out.println("Fallback price failed for index " + fallbackIndex + " with error: " + e2.getMessage());
                        priceText = "Price not found";
                    }
                }

                // ---------- Rating Handling ----------
                String ratingText = "N/A";
                try {
                    WebElement ratingElement = wait.until(ExpectedConditions.visibilityOfElementLocated(
                            By.xpath("(//div[@class='style__Info-sc-1xxctwg-17 cksxLr'])[" + (i + 1) + "]")
                    ));
                    ratingText = ratingElement.getText().trim();
                } catch (Exception e) {
                    ratingText = "No rating";
                }

                System.out.println("Item: " + itemText + " | Price: " + priceText + " | Rating: " + ratingText);
            }

        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        } finally {
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ie) {
                // ignore
            }
            driver.quit();
        }
    }
}
