import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.FileOutputStream;
import java.time.Duration;
import java.util.List;

public class ZomatoLast {

    public static void main(String[] args) throws Exception {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.zomato.com/namakkal/restaurants?place_name=Namakkal&order-online=1&context=delivery");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        Actions actions = new Actions(driver);

        actions.sendKeys(Keys.ESCAPE).perform();

        WebElement enterLocation = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@class='sc-boCWhm gqCoZG']")));
        enterLocation.click();
        enterLocation.sendKeys("560038");

        Thread.sleep(1000);
        WebElement locationSuggestion = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("(//div[contains(@class,'sc-dYcyhn')])[1]")));
        locationSuggestion.click();

        String[] restaurantNames = {
                "The Good Bowl",
                "The Biryani Life",
                "Firangi bake",
                "Behrouz Biryani",
                "Makhani Darbar"
        };

        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Zomato Menu");
        int rowNum = 0;

        // ✅ Header Row created only once
        Row headerRow = sheet.createRow(rowNum++);
        headerRow.createCell(0).setCellValue("Sr. No");
        headerRow.createCell(1).setCellValue("Restaurant Name");
        headerRow.createCell(2).setCellValue("Dish Name");
        headerRow.createCell(3).setCellValue("Price");

        int srNo = 1; // ✅ Counter for Sr. No

        for (String name : restaurantNames) {

            WebElement searchRestaurant = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//input[@placeholder='Search for restaurant, cuisine or a dish']")));
            searchRestaurant.click();
            searchRestaurant.clear();
            searchRestaurant.sendKeys(name);
            searchRestaurant.sendKeys(Keys.ENTER);

            Thread.sleep(3000);

            try {
                WebElement firstItem = wait.until(ExpectedConditions.elementToBeClickable(
                        By.xpath("(//div[@class='sc-glUWqk GrjUP'])[1]")));
                firstItem.click();
            } catch (Exception e) {
                System.out.println("Restaurant not found: " + name);
                continue;
            }

            JavascriptExecutor js = (JavascriptExecutor) driver;
            long lastHeight = (long) js.executeScript("return document.body.scrollHeight");

            while (true) {
                js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
                Thread.sleep(2000);
                long newHeight = (long) js.executeScript("return document.body.scrollHeight");
                if (newHeight == lastHeight) {
                    break;
                }
                lastHeight = newHeight;
            }

            List<WebElement> itemNames = driver.findElements(By.xpath("//h4[@class='sc-cGCqpu chKhYc']"));
            List<WebElement> itemPrices = driver.findElements(By.xpath("//span[@class='sc-17hyc2s-1 cCiQWA']"));

            int totalItems = Math.min(itemNames.size(), itemPrices.size());
            System.out.println("\nRestaurant: " + name);
            System.out.println("Total items found: " + totalItems);

            for (int i = 0; i < totalItems; i++) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(srNo++); // ✅ Sr. No
                row.createCell(1).setCellValue(name);
                row.createCell(2).setCellValue(itemNames.get(i).getText());
                row.createCell(3).setCellValue(itemPrices.get(i).getText());
                System.out.println((srNo - 1) + ". " + itemNames.get(i).getText() + " - " + itemPrices.get(i).getText());
            }

            driver.navigate().back();
            Thread.sleep(2000);
        }

        // Save Excel file
        FileOutputStream outputStream = new FileOutputStream("Zomato_Menu13.xlsx");
        workbook.write(outputStream);
        workbook.close();
        outputStream.close();

        System.out.println("✅ Data saved to Zomato_Menu.xlsx");
        driver.quit();
    }
}

//location
//div[@class='sc-clNaTc ckqoPM']



//dining ratings
//(//div[@class='sc-1q7bklc-8 kEgyiI'])[1]

//delivery ratings
//(//div[@class='sc-1q7bklc-8 kEgyiI'])[2]
