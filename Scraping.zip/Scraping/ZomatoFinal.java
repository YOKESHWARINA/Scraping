import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.FileOutputStream;
import java.time.Duration;
import java.util.List;

public class ZomatoFinal {

    public static void main(String[] args) throws Exception {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(8));
        Actions actions = new Actions(driver);

        String[] restaurantNames = {
        	"The Good Bowl",
            "The Biryani Life",
            "Firangi bake",
            "Behrouz Biryani",
            "Makhani Darbar"
            
        };

        Workbook workbook = new XSSFWorkbook();

        Sheet menuSheet = workbook.createSheet("Zomato Menu");
        Sheet ratingSheet = workbook.createSheet("Restaurant Ratings");

        int rowNum = 0;
        Row headerRow = menuSheet.createRow(rowNum++);
        headerRow.createCell(0).setCellValue("Sr. No");
        headerRow.createCell(1).setCellValue("Restaurant Name");
        headerRow.createCell(2).setCellValue("Subcategory");
        headerRow.createCell(3).setCellValue("Dish Name");
        headerRow.createCell(4).setCellValue("Price");

        int ratingRowNum = 0;
        Row ratingHeader = ratingSheet.createRow(ratingRowNum++);
        ratingHeader.createCell(0).setCellValue("Restaurant Name");
        ratingHeader.createCell(1).setCellValue("Location");
        ratingHeader.createCell(2).setCellValue("Dining Rating");
        ratingHeader.createCell(3).setCellValue("Delivery Rating");

        int srNo = 1;

        driver.get("https://www.zomato.com/namakkal/restaurants?place_name=Namakkal&order-online=1&context=delivery");
        Thread.sleep(2000);

        try {
            actions.sendKeys(Keys.ESCAPE).perform();
            Thread.sleep(500);
        } catch (Exception ignored) {}

        try {
            WebElement enterLocation = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@class='sc-boCWhm gqCoZG']")));
            enterLocation.click();
            enterLocation.clear();
            enterLocation.sendKeys("560038");
            Thread.sleep(1000);
            WebElement locationSuggestion = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@class,'sc-dYcyhn')])[1]")));
            locationSuggestion.click();
            Thread.sleep(2000);
        } catch (Exception e) {
            System.out.println("⚠️ Location input issue.");
        }

        for (String name : restaurantNames) {
            System.out.println("\n🔍 Searching for: " + name);

            try {
                WebElement searchBar = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Search for restaurant, cuisine or a dish']")));
                searchBar.click();
                searchBar.clear();
                searchBar.sendKeys(name);
                searchBar.sendKeys(Keys.ENTER);
                Thread.sleep(2000);

                WebElement firstItem = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[@class='sc-glUWqk GrjUP'])[1]")));
                firstItem.click();

                // ✅ Ensure sections load before continuing
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//section[@class='sc-bZVNgQ iGYweR']")));
                Thread.sleep(1000);

                // Extract location and ratings
                String locationText = "N/A";
                try {
                    WebElement location = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='sc-clNaTc ckqoPM']")));
                    locationText = location.getText();
                } catch (Exception ignored) {}

                String diningText = "N/A";
                try {
                    WebElement diningRating = driver.findElement(By.xpath("(//div[contains(@class,'kEgyiI')])[1]"));
                    diningText = diningRating.getText();
                } catch (Exception ignored) {}

                String deliveryText = "N/A";
                try {
                    WebElement deliveryRating = driver.findElement(By.xpath("//div[contains(@class,'cILgox') and (contains(text(),'.') or contains(text(),'star'))]"));
                    deliveryText = deliveryRating.getText();
                } catch (Exception ignored) {}

                System.out.println("📍 Location: " + locationText);
                System.out.println("🍽️ Dining Rating: " + diningText);
                System.out.println("🚚 Delivery Rating: " + deliveryText);

                Row ratingRow = ratingSheet.createRow(ratingRowNum++);
                ratingRow.createCell(0).setCellValue(name);
                ratingRow.createCell(1).setCellValue(locationText);
                ratingRow.createCell(2).setCellValue(diningText);
                ratingRow.createCell(3).setCellValue(deliveryText);

                // Scroll down to load dishes
                JavascriptExecutor js = (JavascriptExecutor) driver;
                for (int i = 0; i < 5; i++) {
                    js.executeScript("window.scrollBy(0, 1500);");
                    Thread.sleep(1000); // Wait after each scroll for content to load
                }

                // Extract menu sections and items
                List<WebElement> sections = driver.findElements(By.xpath("//section[@class='sc-bZVNgQ iGYweR']"));

                for (WebElement section : sections) {
                    String subcategory = "Others";

                    // Try the first XPath for subcategory
                    try {
                        WebElement subcategoryHeading = section.findElement(By.xpath(".//h4[@class='sc-1hp8d8a-0 sc-liPmeQ iZwYBC']"));
                        subcategory = subcategoryHeading.getText().trim();
                    } catch (Exception e1) {
                        // If the first XPath fails, try the second XPath
                        try {
                            WebElement subcategoryHeading = section.findElement(By.xpath(".//h4[@class='sc-1hp8d8a-0 sc-liPmeQ igGaJp']"));
                            subcategory = subcategoryHeading.getText().trim();
                        } catch (Exception e2) {
                            // If both fail, keep the default subcategory value
                            System.out.println("⚠️ No subcategory found, using default.");
                        }
                    }

                    // Extract items and prices
                    List<WebElement> items = section.findElements(By.xpath(".//h4[@class='sc-cGCqpu chKhYc']"));
                    List<WebElement> prices = section.findElements(By.xpath(".//span[@class='sc-17hyc2s-1 cCiQWA']"));

                    int itemCount = Math.min(items.size(), prices.size());

                    for (int i = 0; i < itemCount; i++) {
                        String itemName = items.get(i).getText();
                        String itemPrice = prices.get(i).getText();

                        Row row = menuSheet.createRow(rowNum++);
                        row.createCell(0).setCellValue(srNo++);
                        row.createCell(1).setCellValue(name);
                        row.createCell(2).setCellValue(subcategory);
                        row.createCell(3).setCellValue(itemName);
                        row.createCell(4).setCellValue(itemPrice);

                        System.out.println("   ➤ " + subcategory + " - " + itemName + " - " + itemPrice);
                    }
                }

                driver.navigate().back();
                wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Search for restaurant, cuisine or a dish']")));
                Thread.sleep(1000);

            } catch (Exception e) {
                System.out.println("❌ Could not fetch data for: " + name);
            }
        }

        // Save data to Excel
        FileOutputStream outputStream = new FileOutputStream("Zomato_Menu_With_Subcategory4.xlsx");
        workbook.write(outputStream);
        workbook.close();
        outputStream.close();

        System.out.println("✅ Data saved to Zomato_Menu_With_Subcategory.xlsx");
        driver.quit();
    }
}
