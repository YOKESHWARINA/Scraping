package Worxogo;

	import com.opencsv.CSVReader;
	import com.opencsv.CSVWriter;

	import java.io.*;
	import java.time.LocalDate;
	import java.time.format.DateTimeFormatter;

	public class Lign_Abott_Demo {
	    public static void main(String[] args) {
	        File inputDir = new File("./Input Data/Lign_Abott/");
	        File[] csvFiles = inputDir.listFiles((dir, name) -> name.endsWith(".csv"));

	        if (csvFiles == null || csvFiles.length == 0) {
	            System.out.println("No CSV files found in Input Data/Lign_Abott folder.");
	            return;
	        }

	        String currentDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
	        File outputDir = new File("./Output/Lign_Abott/");
	        outputDir.mkdirs(); // Ensure output directory exists

	        for (File inputFile : csvFiles) {
	            String inputFileName = inputFile.getName();

	            // Replace the old date and UnverifiedNudges in the filename
	            String updatedName = inputFileName
	                    .replaceAll("\\d{4}-\\d{2}-\\d{2}", currentDate) // Replace old date with today's date
	                    .replace("UnverifiedNudges", "verifiedNudges");

	            String outputPath = "./Output/Lign_Abott/" + updatedName;

	            try (CSVReader reader = new CSVReader(new FileReader(inputFile));
	                 CSVWriter writer = new CSVWriter(new FileWriter(outputPath))) {

	                String[] row;
	                int rowIndex = 0;
	                while ((row = reader.readNext()) != null) {
	                    if (rowIndex == 0) {
	                        writer.writeNext(new String[]{"client_id", "nudge_id", "is_verified"});
	                    } else {
	                        String clientId = row.length > 0 ? row[0] : "";
	                        String nudgeId = row.length > 1 ? row[1] : "";
	                        writer.writeNext(new String[]{clientId, nudgeId, "1"});
	                    }
	                    rowIndex++;
	                }

	                System.out.println("Processed: " + inputFileName + " ➝ " + updatedName);
	            } catch (Exception e) {
	                System.out.println("Error processing file: " + inputFileName);
	                e.printStackTrace();
	            }
	        }

	        System.out.println("✅ All CSV files processed.");
	    }
	}

