package Worxogo;

import com.opencsv.CSVReader;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class Transaction_Sheet {
    public static void main(String[] args) throws Exception {
        String inputCsv = "./Input Data/Transaction_File/transactions_sheet.csv"; // Input file
        String outputExcel = "filtered_data.xlsx"; // Output file
        String targetDate = "27-04-2025"; // Date to filter

        // Date formats
        SimpleDateFormat csvDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); // actual format in CSV
        SimpleDateFormat targetFormat = new SimpleDateFormat("dd-MM-yyyy"); // format for matching

        List<String[]> filteredRows = new ArrayList<>();
        String[] header = null;

        try (CSVReader reader = new CSVReader(new FileReader(inputCsv))) {
            String[] line;
            header = reader.readNext(); // read header
            int dateColumnIndex = -1;

            // Find "day" column index
            for (int i = 0; i < header.length; i++) {
                if (header[i].trim().equalsIgnoreCase("day")) {
                    dateColumnIndex = i;
                    break;
                }
            }

            if (dateColumnIndex == -1) {
                System.err.println("❌ 'day' column not found in header.");
                return;
            }

            int matchCount = 0;
            while ((line = reader.readNext()) != null) {
                try {
                    String rawDateStr = line[dateColumnIndex].trim();
                    Date parsedDate = csvDateFormat.parse(rawDateStr);
                    String formattedDate = targetFormat.format(parsedDate);

                    if (formattedDate.equals(targetDate)) {
                        filteredRows.add(line);
                        matchCount++;
                    }
                } catch (Exception e) {
                    System.err.println("⚠️ Skipped row (invalid date): " + Arrays.toString(line));
                }
            }

            System.out.println("✅ Total matching rows found: " + matchCount);
        }

        // Write filtered data to Excel
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Filtered Data");
            int rowIndex = 0;

            // Write header
            Row headerRow = sheet.createRow(rowIndex++);
            for (int i = 0; i < header.length; i++) {
                headerRow.createCell(i).setCellValue(header[i]);
            }

            // Write matching rows
            for (String[] row : filteredRows) {
                Row excelRow = sheet.createRow(rowIndex++);
                for (int i = 0; i < row.length; i++) {
                    excelRow.createCell(i).setCellValue(row[i]);
                }
            }

            try (FileOutputStream out = new FileOutputStream(outputExcel)) {
                workbook.write(out);
            }
        }

        System.out.println("✅ Filtered data written to: " + outputExcel);
    }
}
