
	package Blinkit;

	import java.util.HashMap;
import java.util.List;
import java.util.Map;

	import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.PageLoadStrategy;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.chrome.ChromeOptions;
	import org.openqa.selenium.support.ui.WebDriverWait;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import java.time.Duration;

	public class Chromeoptmization {

	    public static WebDriver createOptimizedDriver() {
	        ChromeOptions options = new ChromeOptions();

	        Map<String, Object> prefs = new HashMap<>();
	        prefs.put("profile.managed_default_content_settings.images", 2);
	        options.setExperimentalOption("prefs", prefs);

	        options.setPageLoadStrategy(PageLoadStrategy.EAGER);

	        return new ChromeDriver(options);
	    }

	    public static void main(String[] args) {
	        WebDriver driver = createOptimizedDriver();
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	        try {
	            driver.get("https://www.sebi.gov.in/");
	            driver.manage().window().maximize();

	            WebElement enforcementClick = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='menu3']")));
	            enforcementClick.click();

	            WebElement ordersClick = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Orders >>']")));
	            ordersClick.click();

	            WebElement settlementOrder = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Settlement Order']")));
	            settlementOrder.click();

	            System.out.println("Navigation successful.");
	            
	            List<WebElement> count=driver.findElements(By.xpath("//table[@class='table table-striped table-bordered table-hover bordered fix_table dataTable no-footer']//tbody//tr"));
                int size1=count.size();
                
                
                
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            driver.quit();
	        }
	    }
	}

