import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

// Custom class to store item data
class ItemData {
    String restaurant;
    String url;
    String name;
    String price;
    String rating;

    ItemData(String restaurant, String url, String name, String price, String rating) {
        this.restaurant = restaurant;
        this.url = url;
        this.name = name;
        this.price = price;
        this.rating = rating;
    }

    @Override
    public String toString() {
        return "Item [Restaurant=" + restaurant + ", URL=" + url + ", Name=" + name + ", Price=" + price + ", Rating=" + rating + "]";
    }
}

public class EatsureURL {

    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        WebDriverWait shortWait = new WebDriverWait(driver, Duration.ofSeconds(5));
        List<ItemData> itemDataList = new ArrayList<>();

        try {
            // Initial pincode entry
            driver.get("https://www.eatsure.com/");
            clearPopups(driver);

            enterPincode(driver, wait);
            System.out.println("Pincode entered and submitted successfully!");

            // Click Explore Restaurants
            WebElement exploreRestaurants = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[@class='Button-sc-3qnwiq-0 kVKCgs']")));
            exploreRestaurants.click();

            // List of restaurants to check
            List<String> restaurants = Arrays.asList(
                    "The Good Bowl",
                    "The Biryani Life",
                    "Firangi Bake",
                    "Behrouz Biryani",
                    "Makhani Darbar"
            );

            for (String expectedText : restaurants) {
                System.out.println("Processing restaurant: " + expectedText);

                // Ensure restaurant selection page
                wait.until(ExpectedConditions.presenceOfElementLocated(
                        By.xpath("//div[@class='style__BrandName-sc-1y2oa9k-5 leOroS']//p")));

                boolean found = false;
                // Re-locate elements inside the loop to avoid stale references
                List<WebElement> brandElements = driver.findElements(
                        By.xpath("//div[@class='style__BrandName-sc-1y2oa9k-5 leOroS']//p"));
                for (WebElement element : brandElements) {
                    String actualText = element.getText().trim();
                    if (actualText.equalsIgnoreCase(expectedText.trim())) {
                        ((JavascriptExecutor) driver).executeScript(
                                "arguments[0].scrollIntoView({behavior: 'instant', block: 'center'});", element);
                        try {
                            element.click();
                            found = true;
                            break;
                        } catch (StaleElementReferenceException e) {
                            System.out.println("Stale element detected, re-locating and retrying...");
                            brandElements = driver.findElements(
                                    By.xpath("//div[@class='style__BrandName-sc-1y2oa9k-5 leOroS']//p"));
                            for (WebElement retryElement : brandElements) {
                                if (retryElement.getText().trim().equalsIgnoreCase(expectedText.trim())) {
                                    retryElement.click();
                                    found = true;
                                    break;
                                }
                            }
                        }
                    }
                }

                if (!found) {
                    System.out.println("Brand not found: " + expectedText);
                    resetToHomepage(driver, wait);
                    continue;
                }

                // Wait for items to load
                wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='style__Title-sc-1xxctwg-8 dmwYVP']")));

                // Scroll to load all products efficiently
                long lastHeight = (long) ((JavascriptExecutor) driver).executeScript("return document.body.scrollHeight");
                while (true) {
                    ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight);");
                    Thread.sleep(500);
                    long newHeight = (long) ((JavascriptExecutor) driver).executeScript("return document.body.scrollHeight");
                    if (newHeight == lastHeight) break;
                    lastHeight = newHeight;
                }

                // Extract product details
                List<WebElement> productCards = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(
                        By.xpath("//div[@class='style__Title-sc-1xxctwg-8 dmwYVP']/ancestor::a")));
                System.out.println("Found " + productCards.size() + " product cards for " + expectedText);

                for (WebElement card : productCards) {
                    try {
                        String url = card.getAttribute("href");
                        if (url == null || url.isEmpty()) {
                            System.out.println("✗ Skipping card: No URL found");
                            continue;
                        }

                        WebElement nameElement = card.findElement(By.xpath(".//div[@class='style__Title-sc-1xxctwg-8 dmwYVP']"));
                        String name = nameElement.getText().trim();

                        String price = "N/A";
                        boolean onDetailsPage = false;
                        try {
                            WebElement priceElement = card.findElement(By.xpath(".//*[contains(@class,'style__OfferPrice') or contains(@class,'price')][1]"));
                            String rawPrice = priceElement.getText().trim();
                            String[] prices = rawPrice.split("₹");
                            for (String p : prices) {
                                if (!p.isEmpty()) {
                                    price = "₹" + p.replaceAll("[^0-9]", "").trim();
                                    break; // Take the first valid price after ₹
                                }
                            }
                        } catch (Exception e) {
                            System.out.println("✗ No price found for " + name + ", falling back to details page");
                            driver.get(url);
                            onDetailsPage = true;
                            try {
                                WebElement priceElement = wait.until(ExpectedConditions.visibilityOfElementLocated(
                                        By.xpath("//h6[@class='style__OfferPrice-jfito-3 llYpsM priceTypeSlashed_PDP_PriceBar']//div")));
                                String rawPrice = priceElement.getText().trim();
                                String[] prices = rawPrice.split("₹");
                                for (String p : prices) {
                                    if (!p.isEmpty()) {
                                        price = "₹" + p.replaceAll("[^0-9]", "").trim();
                                        break; // Take the first valid price after ₹
                                    }
                                }
                            } catch (Exception ex) {
                                System.out.println("✗ Details page price not found for " + name);
                            }
                        }

                        String rating = "N/A";
                        try {
                            WebElement ratingElement = card.findElement(By.xpath(".//div[@class='style__Info-sc-1xxctwg-17 cksxLr']//div"));
                            String rawRating = ratingElement.getText().trim();
                            String cleanedRating = rawRating.replaceAll("[^0-9.]", "");
                            if (cleanedRating.matches("\\d+\\.\\d+")) {
                                rating = cleanedRating;
                            } else {
                                System.out.println("✗ Invalid rating format for " + name + ": " + rawRating);
                            }
                        } catch (Exception e) {
                            System.out.println("✗ No rating found for " + name);
                        }

                        itemDataList.add(new ItemData(expectedText, url, name, price, rating));
                        System.out.println("✓ " + expectedText + " | " + name + " | " + price + " | " + rating + " | " + url);

                        // Navigate back to item list if on details page
                        if (onDetailsPage) {
                            driver.navigate().back();
                            wait.until(ExpectedConditions.presenceOfElementLocated(
                                    By.xpath("//div[@class='style__Title-sc-1xxctwg-8 dmwYVP']")));
                        }
                    } catch (Exception e) {
                        System.out.println("✗ Error parsing card: " + e.getMessage());
                    }
                }

                // Navigate back to restaurant selection page with stabilization
                try {
                    driver.navigate().back();
                    wait.until(ExpectedConditions.presenceOfElementLocated(
                            By.xpath("//div[@class='style__BrandName-sc-1y2oa9k-5 leOroS']//p")));
                    // Additional wait to ensure DOM is stable
                    Thread.sleep(1000); // Wait 1 second for page stabilization
                    System.out.println("✓ Navigated back to restaurant selection page");
                } catch (Exception e) {
                    System.out.println("✗ Back navigation failed: " + e.getMessage());
                    resetToHomepage(driver, wait);
                }
            }

            // Write to Excel after scraping all data
            writeToExcel(itemDataList);

        } catch (Exception e) {
            System.out.println("Main error: " + e.getMessage());
        } finally {
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ie) {
                // ignore
            }
            driver.quit();
        }
    }

    private static void clearPopups(WebDriver driver) {
        for (int i = 0; i < 5; i++) {
            driver.findElement(By.tagName("body")).sendKeys(Keys.ESCAPE);
            try {
                List<WebElement> closeButtons = driver.findElements(By.xpath("//button[contains(@class, 'close') or contains(text(), 'Close')]"));
                for (WebElement button : closeButtons) {
                    try {
                        button.click();
                    } catch (Exception e) {
                        // Ignore
                    }
                }
                Thread.sleep(500);
            } catch (InterruptedException e) {
                // ignore
            }
        }
    }

    private static void enterPincode(WebDriver driver, WebDriverWait wait) {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[@class='Button-sc-3qnwiq-0 kVKCgs']")));
            System.out.println("✓ Restaurants accessible without pincode entry");
            return;
        } catch (Exception e) {
            // Proceed to pincode entry
        }

        for (int attempt = 1; attempt <= 2; attempt++) {
            try {
                WebElement locationSearch = null;
                try {
                    locationSearch = wait.until(ExpectedConditions.elementToBeClickable(
                            By.xpath("//input[@type='text' and contains(@placeholder, 'pincode')]")));
                } catch (Exception ex) {
                    System.out.println("✗ Specific pincode input not found, falling back to generic...");
                    locationSearch = wait.until(ExpectedConditions.elementToBeClickable(
                            By.xpath("//input[@type='text']")));
                }

                List<WebElement> inputs = driver.findElements(By.xpath("//input[@type='text']"));
                if (inputs.isEmpty()) {
                    System.out.println("✗ No text inputs found on page");
                } else {
                    System.out.println("Found " + inputs.size() + " text inputs:");
                    for (WebElement input : inputs) {
                        System.out.println("Input: class=" + input.getAttribute("class") + ", placeholder=" + input.getAttribute("placeholder"));
                    }
                }

                locationSearch.click();
                locationSearch.sendKeys("560038");
                wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='iconWrap']")));
                WebElement locationClick = driver.findElement(By.xpath("//div[@id='iconWrap']"));
                locationClick.click();
                return;
            } catch (Exception e) {
                System.out.println("✗ Pincode entry attempt " + attempt + " failed: " + e.getMessage());
                if (attempt == 2) {
                    throw new RuntimeException("Failed to enter pincode after retries: " + e.getMessage());
                }
                driver.get("https://www.eatsure.com/");
                clearPopups(driver);
            }
        }
    }

    private static void resetToHomepage(WebDriver driver, WebDriverWait wait) {
        driver.get("https://www.eatsure.com/");
        clearPopups(driver);
        enterPincode(driver, wait);
        WebElement exploreRestaurants = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[@class='Button-sc-3qnwiq-0 kVKCgs']")));
        exploreRestaurants.click();
    }

    private static void writeToExcel(List<ItemData> itemDataList) {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("ItemData");

        // Create header row
        Row headerRow = sheet.createRow(0);
        String[] headers = {"Restaurant", "URL", "Name", "Price", "Rating"};
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
        }

        // Populate data rows
        int rowNum = 1;
        for (ItemData item : itemDataList) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(item.restaurant);
            row.createCell(1).setCellValue(item.url);
            row.createCell(2).setCellValue(item.name);
            row.createCell(3).setCellValue(item.price);
            row.createCell(4).setCellValue(item.rating);
        }

        // Auto-size columns
        for (int i = 0; i < headers.length; i++) {
            sheet.autoSizeColumn(i);
        }

        // Write to file
        try (FileOutputStream fileOut = new FileOutputStream("eatsure_data2.xlsx")) {
            workbook.write(fileOut);
            System.out.println("Data successfully written to eatsure_data.xlsx");
        } catch (IOException e) {
            System.out.println("Error writing to Excel: " + e.getMessage());
        } finally {
            try {
                workbook.close();
            } catch (IOException e) {
                System.out.println("Error closing workbook: " + e.getMessage());
            }
        }
    }
}