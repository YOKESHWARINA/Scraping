package Blinkit;
import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SampleNaturebasket {

    public static void main(String[] args) {
        // Path to your Excel file
        String excelFilePath = ".\\Input Data\\Nature basket1.xlsx";  // Update path as needed

        // Setup WebDriver
        ChromeOptions options = new ChromeOptions();
        options.setPageLoadStrategy(PageLoadStrategy.EAGER);
        WebDriver driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        WebDriverWait wait = new WebDriverWait(driver, java.time.Duration.ofSeconds(30));

        boolean isPinEntered = false;

        try (FileInputStream fis = new FileInputStream(new File(excelFilePath));
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rows = sheet.iterator();
            rows.next(); // Skip header

            while (rows.hasNext()) {
                Row row = rows.next();

                Cell categoryCell = row.getCell(0); // Column A
                Cell urlCell = row.getCell(1);      // Column B

                if (urlCell == null || urlCell.getCellType() != CellType.STRING) continue;

                String productURL = urlCell.getStringCellValue().trim();
                if (productURL.isEmpty() || !productURL.startsWith("http")) continue;

                String categoryName = (categoryCell != null) ? categoryCell.getStringCellValue().trim() : "NA";

                driver.get(productURL);
                Thread.sleep(3000);

                // ✅ Enter PIN code only once
                if (!isPinEntered) {
                    try {
                        WebElement pinInput = wait.until(ExpectedConditions.elementToBeClickable(
                                By.id("txtPin")));
                        pinInput.clear();
                        pinInput.sendKeys("400001"); // Replace with your PIN code

                        WebElement submitBtn = wait.until(ExpectedConditions.elementToBeClickable(
                                By.id("checkPin")));
                        submitBtn.click();

                        System.out.println("📍 PIN entered successfully!");
                        Thread.sleep(3000);
                        isPinEntered = true;
                    } catch (Exception e) {
                        System.out.println("⚠️ PIN code popup not found or already handled.");
                    }
                }

                String productNameClean = "NA";
                String quantity = "NA";
                String price = "NA";
                int availability = 0;

                try {
                    WebElement productNameElem;
                    try {
                        productNameElem = wait.until(ExpectedConditions.visibilityOfElementLocated(
                                By.xpath("//div[@class='pro-title-fav flat-div']")));
                    } catch (Exception e) {
                        productNameElem = wait.until(ExpectedConditions.visibilityOfElementLocated(
                                By.xpath("//h1[contains(@class, 'pd_Title')]")));
                    }

                    String fullProductName = productNameElem.getText().trim();

                    Pattern pattern = Pattern.compile("^(.*?)(\\(.*?\\)|\\b\\d+\\s?(g|G|gm|Gm|Kg|KG|ml|ML|L|l|pcs?|Pcs?|Pc)\\b.*)$");
                    Matcher matcher = pattern.matcher(fullProductName);

                    if (matcher.find()) {
                        productNameClean = matcher.group(1).trim();
                        quantity = matcher.group(2).trim();
                    } else {
                        productNameClean = fullProductName;
                        try {
                            WebElement fallbackQtyElem = driver.findElement(By.xpath("(//h1[@class='pd_Title'])[2]"));
                            quantity = fallbackQtyElem.getText().replace("Size :", "").trim();
                        } catch (Exception ex) {
                            quantity = "NA";
                        }
                    }
                } catch (Exception e) {
                    System.out.println("⚠️ Product name/quantity not found.");
                }

                try {
                    WebElement priceElem;
                    try {
                        priceElem = wait.until(ExpectedConditions.visibilityOfElementLocated(
                                By.xpath("//div[contains(@class, 'productlist-price')]//span[contains(@class, 'search_PSelling')]")));
                    } catch (Exception ex) {
                        priceElem = wait.until(ExpectedConditions.visibilityOfElementLocated(
                                By.xpath("//span[contains(@class, 'productPrice')]")));
                    }
                    price = priceElem.getText().trim();
                } catch (Exception e) {
                    price = "NA";
                }

                try {
                    if (!driver.findElements(By.xpath("//div[@id='btnAddToCartProductDetail']")).isEmpty()
                            || !driver.findElements(By.xpath("//button[contains(text(),'Add to Cart')]")).isEmpty()) {
                        availability = 1;
                    }
                } catch (Exception e) {
                    availability = 0;
                }

                // Print all extracted info
                System.out.println("\n📂 Category: " + categoryName);
                System.out.println("🌐 URL: " + productURL);
                System.out.println("📝 Name: " + productNameClean);
                System.out.println("📦 Quantity: " + quantity);
                System.out.println("💰 Price: " + price);
                System.out.println("✅ Availability: " + availability);
                System.out.println("--------------------------------------------------");

                Thread.sleep(1000);
            }

        } catch (Exception e) {
            System.out.println("❌ Error occurred: " + e.getMessage());
            e.printStackTrace();
        } finally {
            System.out.println("🛑 Closing browser...");
            driver.quit();
        }
    }
}
