import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class EatsureDemo {

    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        Actions actions = new Actions(driver);

        try {
            driver.get("https://www.eatsure.com/");
            actions.sendKeys(Keys.ESCAPE).perform(); // Dismiss popup

            // Enter pincode
            WebElement locationSearch = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='text']")));
            locationSearch.click();
            locationSearch.sendKeys("560038");

            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='iconWrap']")));
            WebElement locationClick = driver.findElement(By.xpath("//div[@id='iconWrap']"));
            locationClick.click();
            System.out.println("Pincode entered and submitted successfully!");

            // Click Explore Restaurants
            WebElement exploreRestaurants = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[@class='Button-sc-3qnwiq-0 kVKCgs']")));
            exploreRestaurants.click();

            // Scroll and select brand
            String expectedText = "Sweet Truth";
            wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//div[@class='style__BrandName-sc-1y2oa9k-5 leOroS']//p")));

            List<WebElement> brandElements = driver.findElements(
                    By.xpath("//div[@class='style__BrandName-sc-1y2oa9k-5 leOroS']//p"));

            boolean found = false;
            for (WebElement element : brandElements) {
                String actualText = element.getText().trim();
                if (actualText.equalsIgnoreCase(expectedText.trim())) {
                    ((JavascriptExecutor) driver).executeScript(
                            "arguments[0].scrollIntoView({behavior: 'instant', block: 'center'});", element);
                    element.click();
                    found = true;
                    break;
                }
            }

            if (!found) {
                System.out.println("Brand not found: " + expectedText);
                return;
            }

            // Wait for items to load and collect item URLs
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='style__Title-sc-1xxctwg-8 dmwYVP']")));

            List<String> itemUrls = new ArrayList<>();
            boolean newItemsLoaded = true;
            int previousItemCount = 0;
            int scrollLimit = 10;
            int scrollCount = 0;

            while (newItemsLoaded && scrollCount < scrollLimit) {
                scrollCount++;
                List<WebElement> itemList = driver.findElements(By.xpath("//div[@class='style__Title-sc-1xxctwg-8 dmwYVP']"));
                if (itemList.size() == previousItemCount) {
                    newItemsLoaded = false;
                } else {
                    previousItemCount = itemList.size();
                    for (WebElement item : itemList) {
                        try {
                            WebElement linkElement = item.findElement(By.xpath("ancestor::a[@href]"));
                            String url = linkElement.getAttribute("href");
                            if (url != null && !url.isEmpty() && !itemUrls.contains(url)) {
                                itemUrls.add(url);
                            }
                        } catch (Exception e) {
                            // URL not found; skip silently
                        }
                    }
                    ((JavascriptExecutor) driver).executeScript("window.scrollBy(0, 1000);");
                    Thread.sleep(300); // short pause for lazy loading
                }
            }

            System.out.println("Total items found: " + itemUrls.size());

            if (itemUrls.isEmpty()) {
                System.out.println("No item URLs found, falling back to clicking elements.");
                List<WebElement> itemList = driver.findElements(By.xpath("//div[@class='style__Title-sc-1xxctwg-8 dmwYVP']"));
                for (int i = 0; i < itemList.size(); i++) {
                    try {
                        WebElement item = itemList.get(i);
                        ((JavascriptExecutor) driver).executeScript(
                                "arguments[0].scrollIntoView({behavior: 'instant', block: 'center'}); window.scrollBy(0, -100);", item);
                        wait.until(ExpectedConditions.visibilityOf(item));
                        wait.until(ExpectedConditions.elementToBeClickable(item));
                        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", item);

                        WebElement itemName = wait.until(ExpectedConditions.visibilityOfElementLocated(
                                By.xpath("(//h1[@class='style__ProductNameHeading-sc-1qpwqt-34 bPoXeA'])[2]")));
                        WebElement itemPrice = wait.until(ExpectedConditions.visibilityOfElementLocated(
                                By.xpath("//h6[@class='style__OfferPrice-jfito-3 llYpsM priceTypeSlashed_PDP_PriceBar']//div")));

                        System.out.println("Item " + (i + 1) + ": " + itemName.getText() + " - Price: " + itemPrice.getText());

                        driver.navigate().back();
                        actions.sendKeys(Keys.ESCAPE).perform();
                        wait.until(ExpectedConditions.presenceOfElementLocated(
                                By.xpath("//div[@class='style__Title-sc-1xxctwg-8 dmwYVP']")));
                        ((JavascriptExecutor) driver).executeScript("window.scrollBy(0, 1000);");
                        Thread.sleep(300);
                    } catch (Exception e) {
                        System.out.println("Error on item " + (i + 1) + ": " + e.getMessage());
                        break;
                    }
                }
            } else {
                for (int i = 0; i < itemUrls.size(); i++) {
                    try {
                        String url = itemUrls.get(i);
                        driver.get(url);
                        actions.sendKeys(Keys.ESCAPE).perform();

                        WebElement itemName = wait.until(ExpectedConditions.visibilityOfElementLocated(
                                By.xpath("(//h1[@class='style__ProductNameHeading-sc-1qpwqt-34 bPoXeA'])[2]")));
                        WebElement itemPrice = wait.until(ExpectedConditions.visibilityOfElementLocated(
                                By.xpath("//h6[@class='style__OfferPrice-jfito-3 llYpsM priceTypeSlashed_PDP_PriceBar']//div")));

                        System.out.println("Item " + (i + 1) + ": " + itemName.getText() + " - Price: " + itemPrice.getText());
                    } catch (Exception e) {
                        System.out.println("Error on item " + (i + 1) + ": " + e.getMessage());
                        break;
                    }
                }
            }

        } catch (Exception e) {
            System.out.println("Main error: " + e.getMessage());
        } finally {
            try {
                Thread.sleep(3000); // Just to see final output
            } catch (InterruptedException ie) {
                // ignore
            }
            driver.quit();
        }
    }
}
