package Blinkit;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class NatureBasket {
    public static void main(String[] args) {
        ChromeOptions options = new ChromeOptions();
        options.setPageLoadStrategy(PageLoadStrategy.EAGER);
        WebDriver driver = new ChromeDriver(options);

        driver.manage().window().maximize();
        WebDriverWait wait = new WebDriverWait(driver, java.time.Duration.ofSeconds(30));

        try {
            System.out.println("Opening website...");
            driver.get("https://www.naturesbasket.co.in/Online-grocery-shopping/Fruits-Vegetables/31_0_0");
            wait.until(ExpectedConditions.titleContains("Fruits & Vegetables"));

            driver.switchTo().activeElement().sendKeys(Keys.ESCAPE);
            Thread.sleep(1000);

            WebElement pincodeTrigger = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//input[contains(@class, 'servicablepin')]")));
            pincodeTrigger.click();

            WebElement searchBar = wait.until(ExpectedConditions.elementToBeClickable(By.id("txt")));
            searchBar.clear();
            searchBar.sendKeys("110001");
            searchBar.sendKeys(Keys.ENTER);
            Thread.sleep(500);
            WebElement searchBar1 = wait.until(ExpectedConditions.elementToBeClickable(By.id("btnAddPin")));
            searchBar1.click();

            System.out.println("Pincode submitted successfully!");
            Thread.sleep(3000);

            JavascriptExecutor js = (JavascriptExecutor) driver;
            long lastHeight = (long) js.executeScript("return document.body.scrollHeight");

            while (true) {
                js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
                Thread.sleep(2000);
                long newHeight = (long) js.executeScript("return document.body.scrollHeight");
                if (newHeight == lastHeight) break;
                lastHeight = newHeight;
            }

            List<WebElement> products = driver.findElements(By.xpath("//div[@class='source_Class']//*[contains(@class, 'divOuterStructure_Search') and contains(@class, 'pro-id')]"));
            System.out.println("Total matching elements after scrolling: " + products.size());

            for (int i = 0; i < products.size(); i++) {
                WebElement product = products.get(i);
                String clickLink = product.findElement(By.tagName("a")).getAttribute("href");
                System.out.println("\n\uD83D\uDD17 Product " + (i + 1) + " URL: " + clickLink);

                js.executeScript("window.open(arguments[0])", clickLink);
                List<String> tabs = new java.util.ArrayList<>(driver.getWindowHandles());
                if (tabs.size() < 2) {
                    System.out.println("⚠️ New tab did not open. Skipping product.");
                    continue;
                }
                driver.switchTo().window(tabs.get(1));

                Thread.sleep(3000);

                String productNameClean = "NA";
                String quantity = "NA";
                String price = "NA";
                int availability = 0;

                try {
                    WebElement productNameElem;
                    try {
                        productNameElem = wait.until(ExpectedConditions.visibilityOfElementLocated(
                                By.xpath("//div[@class='pro-title-fav flat-div']")));
                    } catch (Exception e) {
                        productNameElem = wait.until(ExpectedConditions.visibilityOfElementLocated(
                                By.xpath("//h1[contains(@class, 'pd_Title')]")));
                    }

                    String fullProductName = productNameElem.getText().trim();

                    Pattern pattern = Pattern.compile("^(.*?)(\\(.*?\\)|\\b\\d+\\s?(g|G|gm|Gm|Kg|KG|ml|ML|L|l|pcs?|Pcs?|Pc)\\b.*)$");
                    Matcher matcher = pattern.matcher(fullProductName);

                    if (matcher.find()) {
                        productNameClean = matcher.group(1).trim();
                        quantity = matcher.group(2).trim();
                    } else {
                        productNameClean = fullProductName;
                        try {
                            WebElement fallbackQtyElem = driver.findElement(By.xpath("(//h1[@class='pd_Title'])[2]"));
                            quantity = fallbackQtyElem.getText().replace("Size :", "").trim(); // ✅ Clean "Size :" part
                        } catch (Exception ex) {
                            quantity = "NA";
                        }
                    }
                } catch (Exception e) {
                    System.out.println("⚠️ Product name/quantity not found.");
                }


                try {
                    WebElement priceElem;
                    try {
                        priceElem = wait.until(ExpectedConditions.visibilityOfElementLocated(
                                By.xpath("//div[contains(@class, 'productlist-price')]//span[contains(@class, 'search_PSelling')]")));
                    } catch (Exception ex) {
                        priceElem = wait.until(ExpectedConditions.visibilityOfElementLocated(
                                By.xpath("//span[contains(@class, 'productPrice')]")));
                    }
                    price = priceElem.getText().trim();
                } catch (Exception e) {
                   // System.out.println("⚠️ Price not found.");
                }

                try {
                    if (!driver.findElements(By.xpath("//div[@id='btnAddToCartProductDetail']")).isEmpty()
                            || !driver.findElements(By.xpath("//button[contains(text(),'Add to Cart')]"))
                            .isEmpty()) {
                        availability = 1;
                    }
                } catch (Exception e) {
                    availability = 0;
                }

                System.out.println("\uD83D\uDCDD Name: " + productNameClean);
                System.out.println("\uD83D\uDCE6 Quantity: " + quantity);
                System.out.println("\uD83D\uDCB0 Price: " + price);
                System.out.println("\uD83D\uDCE6 Availability: " + availability);

                try {
                    driver.close();
                } catch (Exception closeEx) {
                    System.out.println("⚠️ Tab already closed or not found.");
                }

                try {
                    driver.switchTo().window(tabs.get(0));
                } catch (Exception switchEx) {
                    System.out.println("⚠️ Original tab lost. Aborting...");
                    break;
                }

                Thread.sleep(1000);
            }

        } catch (Exception e) {
            System.out.println("❌ Something went wrong: " + e.getMessage());
        } finally {
            System.out.println("\uD83D\uDEA9 Closing browser...");
            driver.quit();
        }
    }
}