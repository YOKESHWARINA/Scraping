package Worxogo;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Lign_Abott_Remove_Whatsapp {
    public static void main(String[] args) {
        File inputDir = new File("./Input Data/Lign_Abott/");
        File[] csvFiles = inputDir.listFiles((dir, name) -> name.endsWith(".csv"));

        if (csvFiles == null || csvFiles.length == 0) {
            System.out.println("No CSV files found in Input Data/Lign_Abott folder.");
            return;
        }

        String currentDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        File outputDir = new File("./Output/Lign_Abott_After_Removed/");
        outputDir.mkdirs(); // Ensure output directory exists

        for (File inputFile : csvFiles) {
            String inputFileName = inputFile.getName();
            String updatedName = inputFileName
                    .replaceAll("\\d{4}-\\d{2}-\\d{2}", currentDate)
                    .replace("UnverifiedNudges", "verifiedNudges");
            String outputPath = "./Output/Lign_Abott_After_Removed/" + updatedName;

            try (CSVReader reader = new CSVReader(new FileReader(inputFile));
                 CSVWriter writer = new CSVWriter(new FileWriter(outputPath))) {

                String[] row;
                int rowIndex = 0;
                Map<String, Integer> columnIndexes = new HashMap<>();

                while ((row = reader.readNext()) != null) {
                    if (rowIndex == 0) {
                        // Map header names to their indexes
                        for (int i = 0; i < row.length; i++) {
                            columnIndexes.put(row[i].trim().toLowerCase(), i);
                        }

                        if (!columnIndexes.keySet().containsAll(Arrays.asList("client_id", "nudge_id", "is_verified", "channel"))) {
                            System.out.println("Missing one or more required columns in file: " + inputFileName);
                            break;
                        }

                        // Write only selected headers
                        writer.writeNext(new String[]{"client_id", "nudge_id", "is_verified"});
                    } else {
                        String channelValue = row[columnIndexes.get("channel")].trim().toLowerCase();
                        if ("whatsapp".equals(channelValue)) {
                            continue; // Skip WhatsApp rows
                        }

                        // Set is_verified to 1
                        row[columnIndexes.get("is_verified")] = "1";

                        // Create a new row with only required columns
                        String[] filteredRow = new String[] {
                                row[columnIndexes.get("client_id")],
                                row[columnIndexes.get("nudge_id")],
                                row[columnIndexes.get("is_verified")]
                        };

                        writer.writeNext(filteredRow);
                    }
                    rowIndex++;
                }

                System.out.println("✅ Processed: " + inputFileName + " ➝ " + updatedName);
            } catch (Exception e) {
                System.out.println("❌ Error processing file: " + inputFileName);
                e.printStackTrace();
            }
        }

        System.out.println("🎉 All CSV files processed.");
    }
}
