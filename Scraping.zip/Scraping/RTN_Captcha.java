package Worxogo;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Duration;
import java.util.Collections;
import java.util.Scanner;

public class RTN_Captcha {
    public static void main(String[] args) {
        // Configure ChromeOptions to reduce automation detection
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--disable-blink-features=AutomationControlled");
        options.addArguments("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
        options.addArguments("--disable-extensions");
        options.addArguments("--start-maximized");
        options.addArguments("--disable-infobars");
        options.addArguments("--disable-notifications");
        options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
        options.setExperimentalOption("useAutomationExtension", false);
        WebDriver driver = new ChromeDriver(options);

        try {
            // Disable webdriver flag
            ((JavascriptExecutor) driver).executeScript(
                "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});" +
                "Object.defineProperty(navigator, 'plugins', {get: () => [1, 2, 3]});" +
                "Object.defineProperty(navigator, 'languages', {get: () => ['en-US', 'en']});"
            );

            // Open the login page
            driver.get("https://app.webpushr.com/login");

            // Create an explicit wait
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            Actions actions = new Actions(driver);

            // Enter email
            WebElement mail = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@class='text-field form-control'])[1]")));
            actions.moveToElement(mail).pause(Duration.ofMillis(500)).click().build().perform();
            mail.sendKeys("kavitha.nw@worxogo.com");
            Thread.sleep(1000);

            // Enter password
            WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@class='text-field form-control'])[2]")));
            actions.moveToElement(password).pause(Duration.ofMillis(500)).click().build().perform();
            password.sendKeys("NW@12345");
            Thread.sleep(1000);

            // Wait for the sign-in button
            WebElement signin = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn btn-primary btn-block mt-3']")));

            // Handle CAPTCHA if present
            if (isCaptchaPresent(driver)) {
                try {
                    // Try clicking the checkbox directly
                    WebElement captchaCheckbox = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='recaptcha-checkbox-border']")));
                    actions.moveToElement(captchaCheckbox).pause(Duration.ofMillis(1000)).click().build().perform();
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//textarea[@id='g-recaptcha-response' and string-length(text()) > 0]")));
                } catch (Exception e) {
                    // Solve with 2Captcha
                    System.out.println("Direct CAPTCHA click failed, solving with 2Captcha...");
                    String captchaSolution = solveCaptcha(driver);

                    // Inject the solution
                    WebElement recaptchaElement = driver.findElement(By.xpath("//div[@class='g-recaptcha']"));
                    String callback = recaptchaElement.getAttribute("data-callback");
                    ((JavascriptExecutor) driver).executeScript(
                        "var textarea = document.getElementById('g-recaptcha-response');" +
                        "textarea.value = arguments[0];" +
                        "textarea.innerText = arguments[0];" +
                        "textarea.style.display = 'block';",
                        captchaSolution
                    );

                    // Debug: Check injected value
                    WebElement gRecaptchaResponse = driver.findElement(By.id("g-recaptcha-response"));
                    System.out.println("g-recaptcha-response value: " + gRecaptchaResponse.getAttribute("value"));

                    // Trigger callback if it exists
                    if (callback != null && !callback.isEmpty()) {
                        System.out.println("Triggering callback: " + callback);
                        ((JavascriptExecutor) driver).executeScript("window['" + callback + "']('" + captchaSolution + "');");
                    } else {
                        // Fallback: Trigger form submission manually
                        System.out.println("No callback found, submitting form manually");
                        ((JavascriptExecutor) driver).executeScript(
                            "var form = document.querySelector('form');" +
                            "var input = document.createElement('input');" +
                            "input.type = 'hidden';" +
                            "input.name = 'g-recaptcha-response';" +
                            "input.value = arguments[0];" +
                            "form.appendChild(input);" +
                            "form.submit();",
                            captchaSolution
                        );
                    }

                    // Wait for the page to process
                    Thread.sleep(3000);
                }
            }

            // Click sign-in
            actions.moveToElement(signin).pause(Duration.ofMillis(500)).click().build().perform();
            Thread.sleep(5000); // Wait to observe the result
            System.out.println("Current URL: " + driver.getCurrentUrl());

        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Uncomment to close the browser
            // driver.quit();
        }
    }

    // Check if CAPTCHA is present
    private static boolean isCaptchaPresent(WebDriver driver) {
        try {
            driver.findElement(By.xpath("//div[@class='g-recaptcha']"));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // Solve CAPTCHA using 2Captcha
    private static String solveCaptcha(WebDriver driver) throws IOException, InterruptedException {
        WebElement recaptchaElement = driver.findElement(By.xpath("//div[@class='g-recaptcha']"));
        String siteKey = recaptchaElement.getAttribute("data-sitekey");
        System.out.println("Site Key: " + siteKey); // Debug
        String pageUrl = "https://app.webpushr.com/login";
        String apiKey = "c7b9e27c7d85196c6526068d1cf3af04"; // Your 2Captcha API key

        // Submit CAPTCHA to 2Captcha
        String url = "http://2captcha.com/in.php?key=" + apiKey + "&method=userrecaptcha&googlekey=" + siteKey + "&pageurl=" + pageUrl;
        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        connection.setRequestMethod("GET");

        Scanner scanner = new Scanner(connection.getInputStream());
        String response = scanner.nextLine();
        scanner.close();
        System.out.println("2Captcha Submission Response: " + response); // Debug
        if (!response.startsWith("OK")) {
            throw new IOException("Failed to submit CAPTCHA to 2Captcha: " + response);
        }
        String captchaId = response.split("\\|")[1];

        // Poll for the solution
        String solutionUrl = "http://2captcha.com/res.php?key=" + apiKey + "&action=get&id=" + captchaId;
        String captchaSolution = "";
        for (int i = 0; i < 12; i++) {
            Thread.sleep(10000);
            connection = (HttpURLConnection) new URL(solutionUrl).openConnection();
            scanner = new Scanner(connection.getInputStream());
            response = scanner.nextLine();
            scanner.close();
            System.out.println("2Captcha Poll Response: " + response); // Debug
            if (response.startsWith("OK")) {
                captchaSolution = response.split("\\|")[1];
                break;
            } else if (!response.equals("CAPCHA_NOT_READY")) {
                throw new IOException("Error while polling 2Captcha: " + response);
            }
        }

        if (captchaSolution.isEmpty()) {
            throw new IOException("Failed to get CAPTCHA solution within time limit");
        }
        System.out.println("Captcha Solution: " + captchaSolution); // Debug
        return captchaSolution;
    }
}