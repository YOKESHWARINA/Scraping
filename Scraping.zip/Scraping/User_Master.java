package Worxogo;

import java.io.*;
import java.util.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

public class User_Master {

    public static void main(String args[]) {
        // Set up the input and output directories
        File inputDir = new File("./Input Data/User_Master_File/");
        File[] csvFiles = inputDir.listFiles((dir, name) -> name.endsWith(".csv"));

        if (csvFiles == null || csvFiles.length == 0) {
            System.out.println("No CSV files found in Input Data/User_Master folder.");
            return;
        }

        // Current date for file renaming
        String currentDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        File outputDir = new File("./Output/User_Master_Output_File/");
        outputDir.mkdirs(); // Ensure output directory exists

        for (File inputFile : csvFiles) {
            // Set the output file name as 'User_Master_YYYY-MM-DD.csv'
            String updatedName = "User_Master_" + currentDate + ".csv";
            String outputPath = "./Output/User_Master_Output_File/" + updatedName;

            try (CSVReader reader = new CSVReader(new FileReader(inputFile));
                 CSVWriter writer = new CSVWriter(new FileWriter(outputPath))) {

                String[] row;
                int rowIndex = 0;
                Map<String, Integer> columnIndexes = new HashMap<>();

                // Read through each row in the CSV
                while ((row = reader.readNext()) != null) {
                    if (rowIndex == 0) {
                        // Get column indexes based on the header row
                        for (int i = 0; i < row.length; i++) {
                            columnIndexes.put(row[i].trim().toLowerCase(), i);
                        }

                        // Ensure the 'Status' and 'Role' columns exist
                        if (!columnIndexes.containsKey("status") || !columnIndexes.containsKey("role")) {
                            System.out.println("No 'Status' or 'Role' column found in file: " + inputFile.getName());
                            break;
                        }

                        // Write the header row to the output file
                        writer.writeNext(row);
                    } else {
                        // Check if 'Status' is 'Inactive' or 'Role' is 'Support' and skip this row if true
                        String statusValue = row[columnIndexes.get("status")].trim().toLowerCase();
                        String roleValue = row[columnIndexes.get("role")].trim().toLowerCase();

                        if ("inactive".equals(statusValue) || "support".equals(roleValue)) {
                            continue; // Skip this row if either condition is met
                        }

                        // Write the row that is not "Inactive" and does not have "Support" as role
                        writer.writeNext(row);
                    }
                    rowIndex++;
                }

                System.out.println("✅ Processed: " + inputFile.getName() + " ➝ " + updatedName);

            } catch (Exception e) {
                System.out.println("❌ Error processing file: " + inputFile.getName());
                e.printStackTrace();
            }
        }

        System.out.println("🎉 All CSV files processed.");
    }
}
