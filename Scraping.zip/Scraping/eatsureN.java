import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class eatsureN {

    static class RestaurantItem {
        int serialNo;
        String restaurant;
        String subCategory; // Added subcategory field
        String name;
        String price;
        String rating;
        String mrp;

        RestaurantItem(int serialNo, String restaurant, String subCategory, String name, String price, String rating, String mrp) {
            this.serialNo = serialNo;
            this.restaurant = restaurant;
            this.subCategory = subCategory;
            this.name = name;
            this.price = price;
            this.rating = rating;
            this.mrp = mrp;
        }
    }

    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        Actions actions = new Actions(driver);
        List<RestaurantItem> itemsList = new ArrayList<>();
        int globalSerialNo = 1;

        try {
            driver.get("https://www.eatsure.com/");
            actions.sendKeys(Keys.ESCAPE).perform();

            WebElement locationSearch = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='text']")));
            locationSearch.click();
            locationSearch.sendKeys("560038");
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='iconWrap']"))).click();
            System.out.println("Pincode entered and submitted successfully!");

            WebElement exploreRestaurants = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[@class='Button-sc-3qnwiq-0 kVKCgs']")));
            exploreRestaurants.click();

            List<String> restaurantList = Arrays.asList(
                    "The Good Bowl",
                    "Firangi Bake",
                    "The Biryani Life",
                    "Behrouz Biryani",
                    "Makhani Darbar");

            for (String expectedText : restaurantList) {
                try {
                    System.out.println("\nSearching for restaurant: " + expectedText);
                    wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(
                            By.xpath("//div[@class='style__BrandName-sc-1y2oa9k-5 leOroS']//p")));

                    List<WebElement> brandElements = driver.findElements(
                            By.xpath("//div[@class='style__BrandName-sc-1y2oa9k-5 leOroS']//p"));

                    boolean found = false;
                    for (WebElement element : brandElements) {
                        String actualText = element.getText().trim();
                        if (actualText.equalsIgnoreCase(expectedText.trim())) {
                            System.out.println("Match found: " + actualText + " — Scrolling and Clicking the element!");
                            ((JavascriptExecutor) driver).executeScript(
                                    "arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", element);
                            Thread.sleep(1000);
                            element.click();
                            found = true;
                            break;
                        }
                    }

                    if (!found) {
                        System.out.println("No matching element found for: " + expectedText);
                        continue;
                    }

                    WebElement restaurantName = wait.until(ExpectedConditions.visibilityOfElementLocated(
                            By.xpath("//div[@class='style__BrandName-p7ijs4-11 kNxxtn']")));
                    ((JavascriptExecutor) driver).executeScript(
                            "arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", restaurantName);
                    String resName = restaurantName.getText();
                    System.out.println("Restaurant Name: " + resName);

                    // Scroll to load all items
                    JavascriptExecutor js = (JavascriptExecutor) driver;
                    for (int i = 0; i < 10; i++) {
                        js.executeScript("window.scrollBy(0, 3000)");
                        Thread.sleep(1000);
                    }

                    // Find all item containers
                    List<WebElement> itemContainers = driver.findElements(By.xpath("//div[@class='sc-hKwCoD kPwire']//div[@class='sc-dkPtyc fydAkz']"));
                    System.out.println("Total item containers found: " + itemContainers.size());
                    for (WebElement container : itemContainers) {
                        String subCategory = "Unknown Category";
                        try {
                            WebElement subCategoryElement = container.findElement(By.xpath(".//h6[@data-qa='collectionName']"));
                            subCategory = subCategoryElement.getText().trim();
                        } catch (Exception e) {
                            System.out.println("No subcategory header found for container, using default: " + subCategory);
                        }

                        List<WebElement> items = container.findElements(By.xpath(".//figure[@class='style__Card-sc-1xxctwg-0 exocxh']"));
                        for (WebElement item : items) {
                            String itemText = "N/A";
                            String priceText = "N/A";
                            String avgRating = "N/A";
                            String mrpText = "N/A";

                            try {
                                // Scroll to the item
                                ((JavascriptExecutor) driver).executeScript(
                                        "arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", item);
                                Thread.sleep(500);

                                // Extract item name
                                List<WebElement> nameElements = item.findElements(By.xpath(".//div[@data-qa='productName']"));
                                if (!nameElements.isEmpty() && nameElements.get(0).isDisplayed()) {
                                    itemText = nameElements.get(0).getText().trim();
                                }

                                // Check for MRP first to determine price XPath
                                List<WebElement> mrpElements = item.findElements(
                                        By.xpath(".//span[@class='style__Price-jfito-2 bVtSah']"));
                                if (!mrpElements.isEmpty() && mrpElements.get(0).isDisplayed()) {
                                    String rawMrp = mrpElements.get(0).getText().trim().replaceAll("[\\n\\r]+", " ");
                                    mrpText = "₹" + rawMrp;

                                    // Use productPricePlp XPath for price when MRP is present
                                    List<WebElement> priceElements = item.findElements(
                                            By.xpath(".//div[@data-qa='productPricePlp']"));
                                    if (!priceElements.isEmpty() && priceElements.get(0).isDisplayed()) {
                                        priceText = priceElements.get(0).getText().trim().replaceAll("[\\n\\r]+", " ");
                                    }
                                } else {
                                    // Use totalPrice XPath for price when MRP is not present
                                    List<WebElement> priceElements = item.findElements(
                                            By.xpath(".//span[@data-qa='totalPrice']"));
                                    if (!priceElements.isEmpty() && priceElements.get(0).isDisplayed()) {
                                        priceText = priceElements.get(0).getText().trim().replaceAll("[\\n\\r]+", " ");
                                    }
                                }

                                // Extract rating
                                List<WebElement> ratingElements = item.findElements(
                                        By.xpath(".//div[@class='DisplayRating__RatingTag-sc-1mjg3vv-0 hOkpqp']"));
                                if (!ratingElements.isEmpty() && ratingElements.get(0).isDisplayed()) {
                                    avgRating = ratingElements.get(0).getText().trim().replaceAll("[^0-9.]", "");
                                }

                                // Print details
                                System.out.println("S.No " + globalSerialNo);
                                System.out.println("Restaurant: " + resName);
                                System.out.println("SubCategory: " + subCategory);
                                System.out.println("Name: " + itemText);
                                System.out.println("Price: " + priceText);
                                System.out.println("Rating: " + avgRating);
                                System.out.println("MRP: " + mrpText);
                                System.out.println("----------------------------------------------------");

                                // Add to items list
                                itemsList.add(new RestaurantItem(
                                        globalSerialNo,
                                        resName,
                                        subCategory,
                                        itemText,
                                        priceText,
                                        avgRating,
                                        mrpText
                                ));
                                globalSerialNo++;

                            } catch (Exception e) {
                                System.out.println("Error processing item in " + resName + ": " + e.getMessage());
                            }
                        }
                    }

                    driver.navigate().back();
                    Thread.sleep(2000);

                    try {
                        exploreRestaurants = wait.until(ExpectedConditions.elementToBeClickable(
                                By.xpath("//button[@class='Button-sc-3qnwiq-0 kVKCgs']")));
                        if (exploreRestaurants.isDisplayed()) {
                            exploreRestaurants.click();
                        }
                    } catch (Exception e) {
                        System.out.println("Error re-clicking Explore Restaurants: " + e.getMessage());
                    }

                } catch (Exception e) {
                    System.out.println("Error processing restaurant " + expectedText + ": " + e.getMessage());
                    driver.navigate().back();
                    Thread.sleep(2000);
                    try {
                        exploreRestaurants = wait.until(ExpectedConditions.elementToBeClickable(
                                By.xpath("//button[@class='Button-sc-3qnwiq-0 kVKCgs']")));
                        exploreRestaurants.click();
                    } catch (Exception ex) {
                    }
                }
            }

            // Write to Excel
            writeToExcel(itemsList);

        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        } finally {
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ie) {
                // Ignore
            }
            driver.quit();
        }
    }

    private static void writeToExcel(List<RestaurantItem> itemsList) {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Restaurant Details");

        // Create header row
        Row headerRow = sheet.createRow(0);
        String[] headers = {"S.No", "Restaurant", "SubCategory", "Name", "MRP", "Price", "Rating"};
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
        }

        // Populate data rows
        int rowNum = 1;
        for (RestaurantItem item : itemsList) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(item.serialNo);
            row.createCell(1).setCellValue(item.restaurant);
            row.createCell(2).setCellValue(item.subCategory);
            row.createCell(3).setCellValue(item.name);
            row.createCell(4).setCellValue(item.mrp);
            row.createCell(5).setCellValue(item.price);
            row.createCell(6).setCellValue(item.rating);
        }

        // Auto-size columns
        for (int i = 0; i < headers.length; i++) {
            sheet.autoSizeColumn(i);
        }

        // Write to file
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
        String timestamp = dateFormat.format(new Date());
        String outputFilePath = ".\\Output\\EatSure_Restaurant_Output_" + timestamp + ".xlsx";
        try (FileOutputStream fileOut = new FileOutputStream(outputFilePath)) {
            workbook.write(fileOut);
            System.out.println("Excel file created successfully: " + outputFilePath);
        } catch (Exception e) {
            System.out.println("Error writing to Excel: " + e.getMessage());
        } finally {
            try {
                workbook.close();
            } catch (Exception e) {
                System.out.println("Error closing workbook: " + e.getMessage());
            }
        }
    }
}