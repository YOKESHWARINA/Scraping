package Blinkit;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.*;
import java.time.Duration;
import java.util.*;

public class splitheader {

    public static void main(String[] args) {
        String inputFile = "./Input Data/OTC_tatamg.xlsx";  // Input Excel
        String outputFile = "ProductInfo_All9.xlsx";        // Output Excel

        List<Map<String, String>> allProductData = new ArrayList<>();
        Set<String> dynamicHeaders = new LinkedHashSet<>();
        dynamicHeaders.add("Description Status"); // add status header first
        WebDriver driver = new ChromeDriver();

        try (FileInputStream fis = new FileInputStream(inputFile);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheet("Sheet2");
            if (sheet == null) {
                throw new RuntimeException("❌ Sheet named 'Sheet2' not found.");
            }

            Row headerRow = sheet.getRow(0);
            if (headerRow == null) {
                throw new RuntimeException("❌ Header row not found in 'Sheet2'.");
            }

            int nameCol = -1, urlCol = -1;
            for (Cell cell : headerRow) {
                if (cell.getStringCellValue().equalsIgnoreCase("INPUT NAME")) nameCol = cell.getColumnIndex();
                if (cell.getStringCellValue().equalsIgnoreCase("URL")) urlCol = cell.getColumnIndex();
            }

            if (nameCol == -1 || urlCol == -1) {
                throw new RuntimeException("❌ 'INPUT NAME' or 'URL' column not found.");
            }

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;

                String name = row.getCell(nameCol).getStringCellValue();
                String url = row.getCell(urlCol).getStringCellValue();

                Map<String, String> productInfo = new LinkedHashMap<>();
                productInfo.put("NAME", name);
                productInfo.put("URL", url);

                try {
                    driver.get(url);

                    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
                    WebElement descriptionDiv = wait.until(ExpectedConditions.presenceOfElementLocated(
                            By.xpath("//div[contains(@class, 'ProductDescription__product-description')]")));

                    String descriptionText = descriptionDiv.getText();
                    Map<String, String> parsed = parseDescriptionDynamically(descriptionText);

                    for (Map.Entry<String, String> entry : parsed.entrySet()) {
                        String key = "Desc - " + entry.getKey();
                        productInfo.put(key, entry.getValue());
                        dynamicHeaders.add(key);
                    }

                    productInfo.put("Description Status", "Description found");

                } catch (TimeoutException | NoSuchElementException e) {
                    System.out.println("❌ Description not found for: " + name);
                    productInfo.put("Description Status", "Description not found");
                } catch (Exception e) {
                    System.out.println("⚠️ Error for: " + name + " -> " + e.getMessage());
                    productInfo.put("Description Status", "Description not found");
                }

                allProductData.add(productInfo);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        driver.quit();
        writeListToExcel(allProductData, outputFile, dynamicHeaders);
    }

    public static Map<String, String> parseDescriptionDynamically(String text) {
        Map<String, String> map = new LinkedHashMap<>();
        String[] lines = text.split("\n");

        String currentHeader = "General Description";
        List<String> contentList = new ArrayList<>();

        for (String line : lines) {
            line = line.trim();
            if (line.isEmpty()) continue;

            boolean isHeader = line.matches(".*:") && line.length() < 50;

            if (isHeader) {
                if (!contentList.isEmpty()) {
                    String content;
                    if (contentList.size() == 1 || currentHeader.equals("General Description")) {
                        content = String.join(" ", contentList);
                    } else {
                        StringBuilder numberedContent = new StringBuilder();
                        for (int i = 0; i < contentList.size(); i++) {
                            numberedContent.append(i + 1).append(". ").append(contentList.get(i)).append(" ");
                        }
                        content = numberedContent.toString().trim();
                    }
                    map.put(currentHeader, content);
                }

                currentHeader = line.substring(0, line.length() - 1); // remove colon
                contentList = new ArrayList<>();
            } else {
                contentList.add(line);
            }
        }

        // Save last section
        if (!contentList.isEmpty()) {
            String content;
            if (contentList.size() == 1 || currentHeader.equals("General Description")) {
                content = String.join(" ", contentList);
            } else {
                StringBuilder numberedContent = new StringBuilder();
                for (int i = 0; i < contentList.size(); i++) {
                    numberedContent.append(i + 1).append(". ").append(contentList.get(i)).append(" ");
                }
                content = numberedContent.toString().trim();
            }
            map.put(currentHeader, content);
        }

        return map;
    }

    public static void writeListToExcel(List<Map<String, String>> dataList, String fileName, Set<String> knownHeaders) {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Product Info");

        List<String> headerList = new ArrayList<>();
        headerList.add("NAME");
        headerList.add("URL");
        headerList.addAll(knownHeaders);

        int rowIndex = 0;
        Row headerRow = sheet.createRow(rowIndex++);
        for (int i = 0; i < headerList.size(); i++) {
            headerRow.createCell(i).setCellValue(headerList.get(i));
        }

        for (Map<String, String> rowMap : dataList) {
            Row row = sheet.createRow(rowIndex++);
            for (int i = 0; i < headerList.size(); i++) {
                String key = headerList.get(i);
                String value = rowMap.getOrDefault(key, "NA");
                row.createCell(i).setCellValue(value);
            }
        }

        for (int i = 0; i < headerList.size(); i++) {
            sheet.autoSizeColumn(i);
        }

        try (FileOutputStream fos = new FileOutputStream(fileName)) {
            workbook.write(fos);
            workbook.close();
            System.out.println("✅ Excel file created: " + fileName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
