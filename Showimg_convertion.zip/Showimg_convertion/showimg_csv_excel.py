import pandas as pd

# Load the CSV file into a pandas DataFrame
csv_file = r"C:\Users\Yokeshwari.7183\Desktop\Showimg_convertion\Output File\showimg32\all_tables.csv"  # Ensure it has .csv extension
df = pd.read_csv(csv_file)

# Write the DataFrame to an Excel file
excel_file = r'C:\Users\Yokeshwari.7183\Desktop\Showimg_convertion\Output File\Showimg_file31.xlsx'  # Full path for output file
df.to_excel(excel_file, index=False, engine='openpyxl')

print(f"CSV file has been converted to Excel and saved as {excel_file}")
