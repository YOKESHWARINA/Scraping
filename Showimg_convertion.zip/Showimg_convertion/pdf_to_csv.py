import camelot
import pandas as pd
import os
from multiprocessing import Pool, cpu_count
from functools import partial
import re


def split_name_reg(cell):
    """Split a cell into name and registration number, handling merged values."""
    # Look for registration pattern in the middle or end
    match = re.search(r'(POP\d{6,})', str(cell))  # Match POP followed by 6+ digits

    if match:
        reg_number = match.group(1)
        name_part = cell.replace(reg_number, '').strip()

        # Handle cases where part of the name was pushed to the next cell
        if ',' in name_part:
            name_parts = name_part.split(',')
            name_part = ' '.join(name_parts).strip()  # Join to form a complete name

        return name_part, reg_number
    else:
        return cell, ''  # Return original if no match


def clean_merged_rows(df):
    """Fix merged rows where name and reg_number are joined across columns."""
    for i in range(len(df)):
        # Check if column 1 or 2 has merged data
        if isinstance(df.iloc[i, 1], str) and isinstance(df.iloc[i, 2], str):
            merged_data = df.iloc[i, 1] + df.iloc[i, 2]

            # If merged, split and fix
            name, reg_number = split_name_reg(merged_data)
            if reg_number:
                df.iloc[i, 1] = name
                df.iloc[i, 2] = reg_number

    return df


def process_table_chunk(chunk_info, pdf_path):
    """Process a chunk of pages and return a combined DataFrame with fixed columns."""
    start_page, end_page = chunk_info
    chunk_range = f"{start_page}-{end_page}"

    try:
        # Extract tables for this chunk
        tables = camelot.read_pdf(
            pdf_path,
            pages=chunk_range,
            flavor="lattice",  # Try 'stream' if lattice fails
            suppress_stdout=True,
            strip_text='\n',
            split_text=True,
            line_scale=40  # Adjust if table lines aren’t detected
        )

        if len(tables) == 0:
            print(f"No tables found in pages {chunk_range}")
            return pd.DataFrame()

        expected_columns = 7  # Adjust based on your table structure
        processed_dfs = []

        for table in tables:
            df = table.df
            print(f"Raw table shape for pages {chunk_range}: {df.shape}")
            
            # Clean merged rows before further processing
            df = clean_merged_rows(df)
            
            # If columns are fewer than expected, assume column 1 and 2 are merged or misaligned
            if df.shape[1] < expected_columns:
                print(f"Detected column misalignment in pages {chunk_range}")
                # Merge columns 1 and 2 (assuming 0-based indexing: 0, 1 are the problematic ones)
                df[1] = df[0].astype(str) + " " + df[1].astype(str)
                df = df.drop(columns=[0]).reset_index(drop=True)  # Drop the first column after merging
                df.columns = range(df.shape[1])  # Reset column indices

            # Now process the table with the corrected structure
            if df.shape[1] == expected_columns - 1:  # Still one column short after merge
                print(f"Fixing merged columns in pages {chunk_range}")
                df['bank_name'], df['reg_number'] = zip(*df[1].apply(split_name_reg))
                new_df = pd.DataFrame({
                    0: df[0],            # Serial number
                    1: df['bank_name'],  # Name
                    2: df['reg_number'], # Registration number
                    3: df[2],            # Next column
                    4: df[3],
                    5: df[4],
                    6: df[5]
                })
                processed_dfs.append(new_df)
            elif df.shape[1] == expected_columns:
                processed_dfs.append(df)
            else:
                print(f"Unexpected column count ({df.shape[1]}) in pages {chunk_range}")
                processed_dfs.append(df)  # Keep as is for review

        # Combine all tables in this chunk
        combined_df = pd.concat(processed_dfs, ignore_index=True)

        # Clean up: replace commas to avoid CSV formatting issues
        for col in combined_df.columns:
            combined_df[col] = combined_df[col].apply(
                lambda x: str(x).replace(',', ' ').strip() if pd.notna(x) else x
            )

        print(f"Processed chunk {chunk_range} sample:\n{combined_df.head().to_string()}")
        return combined_df

    except Exception as e:
        print(f"Error processing chunk {chunk_range}: {e}")
        return pd.DataFrame()


def extract_and_save(pdf_path, output_dir):
    """Extract tables from PDF, fix columns, and save to a single CSV."""
    print("Starting PDF extraction...")

    # Create output directory if it doesn’t exist
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    try:
        # Define page chunks (adjust based on PDF length)
        total_pages = 5  # Change this based on the actual number of pages
        chunk_size = 5
        page_chunks = [
            (i, min(i + chunk_size - 1, total_pages)) for i in range(1, total_pages + 1, chunk_size)
        ]

        # Process chunks in parallel
        num_cores = min(cpu_count(), len(page_chunks))
        print(f"Using {num_cores} CPU cores for parallel processing...")

        with Pool(processes=num_cores) as pool:
            process_partial = partial(process_table_chunk, pdf_path=pdf_path)
            dfs = pool.map(process_partial, page_chunks)

        # Filter out empty DataFrames
        valid_dfs = [df for df in dfs if not df.empty]
        if not valid_dfs:
            print("No tables found in the PDF.")
            return

        # Combine all chunks into one DataFrame
        combined_df = pd.concat(valid_dfs, ignore_index=True)

        # Save to a single CSV
        output_csv = os.path.join(output_dir, "all_tables.csv")
        combined_df.to_csv(
            output_csv,
            mode='w',
            index=False,
            quoting=1,  # QUOTE_ALL to handle special characters
            encoding='utf-8'
        )
        print(f"Saved all tables to {output_csv}")
        print(f"Total rows: {len(combined_df)}")

    except Exception as e:
        print(f"Error processing the PDF: {e}")


if __name__ == "__main__":
    # File paths
    pdf_path = r"C:\Users\Yokeshwari.7183\Desktop\Showimg_convertion\Input File\showimg.pdf"
    output_dir = r"C:\Users\Yokeshwari.7183\Desktop\Showimg_convertion\Output File\showimg32"

    # Run the extraction
    extract_and_save(pdf_path, output_dir)
